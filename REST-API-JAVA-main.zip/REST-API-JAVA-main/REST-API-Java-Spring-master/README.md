# REST-API-Java-Spring
Simple API made using JAVA Spring boot
