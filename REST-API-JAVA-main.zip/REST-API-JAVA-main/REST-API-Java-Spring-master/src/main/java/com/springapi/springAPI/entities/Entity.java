package com.springapi.springAPI.entities;

public @interface Entity {

}
